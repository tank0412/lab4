CREATE FUNCTION add_rule()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
counts integer := 0;
IsExist integer := 1;
BEGIN
SELECT COUNT(*) INTO counts FROM ПРАВИЛО;
WHILE IsExist != 0 LOOP
counts := counts + 1;
SELECT COUNT(*) INTO IsExist FROM ПРАВИЛО WHERE ИД = counts;
END LOOP;
NEW.ИД := counts;
RETURN NEW;
END
$$;

