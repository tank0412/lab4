CREATE FUNCTION add_students()
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
rooms integer := 0;
names text[] := '{
Владислав,
Иван,
Валерий,
Андрей,
Антон,
Леонид,
Богдан,
Матвей,
Владимир,
Александр,
Кирилл,
Егор,
Сергей,
Максим}';
surnames text[] := '{
Агафонов, 
Аксёнов, 
Александров, 
Алексеев, 
Андреев, 
Анисимов, 
Антонов,
Иванов,
Петров,
Сидоров,
Логинов,
Пассвордов,
Власов, 
Волков, 
Воробьёв, 
Воронов}';
pats text[] := '{
Сергеевич,
Владимирович,
Андреевич,
Алексеевич,
Олегович,
Егорович,
Александрович,
Максимович,
Дмитриевич,
Владиславович,
Федорович,
NULL}';
n integer := 0;
s integer := 0;
p integer := 0;
ids integer[];
id integer := 1;
b_date timestamp := timestamp '1990-01-01 00:00:00';
e_date timestamp := timestamp '2010-01-01 00:00:00';
BEGIN
SELECT COUNT(*) INTO rooms FROM КОМНАТА;
ids := array(SELECT НОМЕР FROM КОМНАТА);
FOR i IN 1..rooms LOOP
FOR j IN 1..4 LOOP
b_date = timestamp '1990-01-01 00:00:00' + (random() * (365 * 9 - 1)) * interval '1 day';
e_date = timestamp '2010-01-01 00:00:00' + random() * (current_date - timestamp '2010-01-01 00:00:00');

n := random() * 13 + 1;
s := random() * 15 + 1;
p := random() * 11 + 1;

INSERT INTO ПРОЖИВАЮЩИЙ VALUES(id, surnames[s], names[n], pats[p], b_date, e_date, ids[i]);
id := id + 1;
END LOOP;
UPDATE КОМНАТА SET ПРОЖИВАЮЩИЙ_ИД = (id - 1) WHERE НОМЕР = ids[i];
END LOOP;
END;
$$;

