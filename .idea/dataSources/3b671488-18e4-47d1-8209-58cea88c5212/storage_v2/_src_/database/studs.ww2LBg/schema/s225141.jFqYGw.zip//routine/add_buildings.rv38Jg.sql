CREATE FUNCTION add_buildings(count integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
FOR i IN 1..count LOOP
INSERT INTO КОРПУС VALUES(i);
END LOOP;
END;
$$;

