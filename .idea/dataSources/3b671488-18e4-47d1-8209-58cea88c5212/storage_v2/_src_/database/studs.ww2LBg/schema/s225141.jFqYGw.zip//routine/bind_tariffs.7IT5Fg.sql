CREATE FUNCTION bind_tariffs()
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
tariffs integer[] := '{1, 1, 2, 2, NULL}';
BEGIN
UPDATE КОМНАТА SET ИНТЕРНЕТ_ТАРИФ_ИД = tariffs[random()*4+1] WHERE НОМЕР = ANY(SELECT НОМЕР FROM КОМНАТА);
END;
$$;

