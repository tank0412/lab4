CREATE FUNCTION on_stud_upd()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
studs integer := 0;
id integer := 0;
BEGIN
SELECT COUNT(*) FROM ПРОЖИВАЮЩИЙ INTO studs WHERE КОМНАТА_НОМЕР = NEW.КОМНАТА_НОМЕР;
IF studs >= 4 THEN
RAISE EXCEPTION 'Данная комната имеет четырех проживающих';
END IF;
IF (TG_OP = 'INSERT') THEN
SELECT CURRENT_DATE INTO NEW.ДАТА_ЗАСЕЛЕНИЯ;
END IF;
IF (TG_OP = 'DELETE') THEN 
NEW.ДАТА_ЗАСЕЛЕНИЯ = OLD.ДАТА_ЗАСЕЛЕНИЯ;
END IF;
RETURN NEW;
END;
$$;

