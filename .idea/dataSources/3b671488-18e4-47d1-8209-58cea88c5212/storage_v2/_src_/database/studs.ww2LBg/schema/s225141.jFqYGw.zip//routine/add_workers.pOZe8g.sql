CREATE FUNCTION add_workers(count integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
names text[] := '{
Владислав,
Иван,
Валерий,
Андрей,
Антон,
Леонид,
Богдан,
Матвей,
Владимир,
Александр,
Кирилл,
Егор,
Сергей,
Максим}';
surnames text[] := '{
Агафонов, 
Аксёнов, 
Александров, 
Алексеев, 
Андреев, 
Анисимов, 
Антонов,
Иванов,
Петров,
Сидоров,
Логинов,
Пассвордов,
Власов, 
Волков, 
Воробьёв, 
Воронов}';
pats text[] := '{
Сергеевич,
Владимирович,
Андреевич,
Алексеевич,
Олегович,
Егорович,
Александрович,
Максимович,
Дмитриевич,
Владиславович,
Федорович,
NULL}';
roles text[] := '{
Садовник,
Электрик,
Уборщик,
Вахтер}';
n integer := 0;
s integer := 0;
p integer := 0;
r integer := 0;
BEGIN
FOR i IN 1..count LOOP
n := random() * 13 + 1;
s := random() * 15 + 1;
p := random() * 11 + 1;
r := random() * 3 + 1;

INSERT INTO РАБОЧИЙ VALUES(i, surnames[s], names[n], pats[p], roles[r]);
END LOOP;
END;
$$;

