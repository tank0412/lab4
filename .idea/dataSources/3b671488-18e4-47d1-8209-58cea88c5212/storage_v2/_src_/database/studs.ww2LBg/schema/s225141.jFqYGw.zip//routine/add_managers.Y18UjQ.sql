CREATE FUNCTION add_managers()
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
names text[] := '{
Владислав,
Иван,
Валерий,
Андрей,
Антон,
Леонид,
Богдан,
Матвей,
Владимир,
Александр,
Кирилл,
Егор,
Сергей,
Максим}';
surnames text[] := '{
Агафонов, 
Аксёнов, 
Александров, 
Алексеев, 
Андреев, 
Анисимов, 
Антонов,
Иванов,
Петров,
Сидоров,
Логинов,
Пассвордов,
Власов, 
Волков, 
Воробьёв, 
Воронов}';
pats text[] := '{
Сергеевич,
Владимирович,
Андреевич,
Алексеевич,
Олегович,
Егорович,
Александрович,
Максимович,
Дмитриевич,
Владиславович,
Федорович,
NULL}';
n integer := 0;
s integer := 0;
p integer := 0;
id integer := 1;
BEGIN
FOR i IN 1..11 LOOP
n := random() * 13 + 1;
s := random() * 15 + 1;
p := random() * 11 + 1;
INSERT INTO УПРАВЛЯЮЩИЙ VALUES(id, names[n], surnames[s], pats[p], 'Заведующий', i);
id := id + 1;

n := random() * 13 + 1;
s := random() * 15 + 1;
p := random() * 11 + 1;

INSERT INTO УПРАВЛЯЮЩИЙ VALUES(id, names[n], surnames[s], pats[p], 'Комендант', i);
id := id + 1;
END LOOP;
END;
$$;

