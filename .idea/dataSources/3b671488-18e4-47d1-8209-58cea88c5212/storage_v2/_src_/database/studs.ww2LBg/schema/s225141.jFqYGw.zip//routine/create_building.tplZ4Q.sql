CREATE FUNCTION create_building()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
buildings integer=0;
BEGIN
SELECT COUNT(*) INTO buildings FROM КОРПУС;
NEW.НОМЕР:=buildings;
FOR i IN 1..10 LOOP
PERFORM create_floor(buildings);
END LOOP;
RETURN NEW;
END;
$$;

