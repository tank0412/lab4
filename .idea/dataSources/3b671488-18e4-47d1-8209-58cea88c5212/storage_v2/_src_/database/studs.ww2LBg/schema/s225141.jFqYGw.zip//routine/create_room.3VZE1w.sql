CREATE FUNCTION create_room(building integer, floor integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
id integer:=0;
rooms integer:=0;
BEGIN
SELECT COUNT(*) INTO rooms FROM КОМНАТА;
id:=building*10000+MOD(floor, 10)*1000+MOD(rooms, 250);
INSERT INTO КОМНАТА VALUES(id, floor, NULL, NULL);
END;
$$;

