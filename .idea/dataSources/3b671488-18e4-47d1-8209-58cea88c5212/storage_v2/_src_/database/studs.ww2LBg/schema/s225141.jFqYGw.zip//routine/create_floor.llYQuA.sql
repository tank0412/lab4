CREATE FUNCTION create_floor(building integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
id integer:=0;
floors integer:=0;
BEGIN
SELECT COUNT(*) INTO floors FROM ЭТАЖ;
id:=building*10+MOD(floors, 10);
INSERT INTO ЭТАЖ VALUES(id, building, NULL);
FOR i IN 1..25 LOOP
PERFORM create_room(building, id);
END LOOP;
END;
$$;

