CREATE FUNCTION add_violations(count integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
s_ids integer[];
s_ids_count integer := 0;
s_id integer := 0;
r_ids integer[];
r_ids_count integer := 0;
r_id integer := 0;
e_date timestamp;
id integer := 1;
BEGIN
SELECT COUNT(*) INTO s_ids_count FROM ПРОЖИВАЮЩИЙ;
s_ids := array(SELECT ИД FROM ПРОЖИВАЮЩИЙ);
SELECT COUNT(*) INTO r_ids_count FROM ПРАВИЛО;
r_ids := array(SELECT ИД FROM ПРАВИЛО);

FOR i IN 1..count LOOP
s_id := random() * (s_ids_count - 1) + 1;
r_id := random() * (r_ids_count - 1) + 1;
SELECT ДАТА_ЗАСЕЛЕНИЯ INTO e_date FROM ПРОЖИВАЮЩИЙ WHERE ИД = s_ids[s_id];

INSERT INTO НАРУШЕНИЕ VALUES(id, e_date + random() * (current_date - e_date), s_ids[s_id], r_ids[r_id]);
id := id + 1;
END LOOP;
END;
$$;

